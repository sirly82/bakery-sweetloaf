<?php
session_start();
require 'db_connect.php'; // Pastikan path ke db_connect.php benar

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Cek apakah user sudah login, jika belum redirect ke login page
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['id'];
$username = $_SESSION['username'];
$nama_user = $_SESSION['nama'];

// Ambil total harga dari sesi atau dari parameter GET jika dialihkan dari process_order.php
// Saya asumsikan process_order.php akan menyimpan grand_total di sesi setelah pesanan dibuat
$grand_total = 0;
$id_pesanan = null;

if (isset($_SESSION['grand_total_for_payment']) && isset($_SESSION['last_order_id'])) {
    $grand_total = $_SESSION['grand_total_for_payment'];
    $id_pesanan = $_SESSION['last_order_id'];

    // Hapus variabel sesi setelah diambil untuk menghindari pembayaran ganda atau masalah lain
    unset($_SESSION['grand_total_for_payment']);
    unset($_SESSION['last_order_id']);
} elseif (isset($_GET['total_harga']) && isset($_GET['id_pesanan'])) {
    // Alternatif jika Anda mengirim melalui GET (kurang disarankan untuk data sensitif)
    $grand_total = (float)$_GET['total_harga'];
    $id_pesanan = (int)$_GET['id_pesanan'];
} else {
    // Jika tidak ada data total harga, bisa diarahkan kembali ke keranjang atau menampilkan pesan error
    // Misalnya, redirect ke halaman keranjang
    header("Location: pesanan.php");
    exit();
}

// Anda bisa mengambil detail pesanan dari database jika id_pesanan tersedia
// Misalnya, untuk menampilkan produk yang dipesan, dll.
// Untuk saat ini, kita hanya akan fokus pada total harga dan QRIS.

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran - SweetLoaf Bakery</title>
    <link rel="stylesheet" href="style.css"> <link rel="stylesheet" href="register.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* Styling spesifik untuk halaman pembayaran */
        .payment-section {
            padding: 80px 0;
            min-height: calc(100vh - 200px); /* Sesuaikan tinggi agar footer di bawah */
            display: flex;
            justify-content: center;
            align-items: flex-start; /* Mengatur item ke atas */
        }

        .payment-container {
            background-color: var(--white);
            padding: 40px;
            border-radius: var(--border-radius-large);
            box-shadow: var(--shadow-medium);
            max-width: 600px;
            width: 100%;
            text-align: center;
            margin-top: 50px; /* Menambah sedikit ruang dari header */
        }

        .payment-container h2 {
            color: var(--dark-grey);
            margin-bottom: 20px;
            font-size: 2em;
        }

        .payment-info p {
            font-size: 1.1em;
            margin-bottom: 10px;
            color: var(--text-color);
        }

        .payment-info .total-amount {
            font-size: 1.8em;
            font-weight: 700;
            color: var(--primary-orange);
            margin-bottom: 30px;
        }

        .qris-section {
            margin-top: 30px;
            margin-bottom: 30px;
            border-top: 1px solid #eee;
            padding-top: 30px;
        }

        .qris-section h3 {
            color: var(--dark-grey);
            margin-bottom: 20px;
            font-size: 1.6em;
        }

        .qris-image {
            width: 80%; /* Sesuaikan ukuran QRIS */
            max-width: 300px;
            height: auto;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-medium);
            padding: 10px;
            background-color: var(--white);
        }

        .payment-instructions {
            margin-top: 20px;
            text-align: left;
            color: var(--text-color);
            line-height: 1.8;
            font-size: 0.95em;
        }

        .payment-instructions ol {
            padding-left: 25px;
            margin-bottom: 20px;
        }

        .payment-instructions li {
            margin-bottom: 10px;
        }

        .btn-confirm-payment {
            width: 100%;
            padding: 15px 20px;
            font-size: 1.1em;
            font-weight: 600;
            margin-top: 20px;
            /* register.css .btn-primary styles will apply */
        }

        /* Responsiveness */
        @media (max-width: 768px) {
            .payment-container {
                padding: 20px;
                margin-top: 20px;
            }
            .payment-container h2 {
                font-size: 1.8em;
            }
            .payment-info .total-amount {
                font-size: 1.5em;
            }
            .qris-image {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <div class="top-wave-container">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#FC8A06" fill-opacity="1" d="M0,288L80,266.7C160,245,320,203,480,186.7C640,171,800,181,960,165.3C1120,149,1280,107,1360,85.3L1440,64L1440,0L1360,0C1280,0,1120,0,960,0C800,0,640,0,480,0C320,0,160,0,80,0L0,0Z"></path>
        </svg>
    </div>

    <header class="main-header">
        <div class="container">
            <div class="logo">
                <img src="assets/logo-home.png" alt="SweetLoaf Logo">
            </div>
            <nav class="main-nav">
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="#">Produk</a></li>
                    <li><a href="#">Tentang Kami</a></li>
                    <li><a href="#">Kontak</a></li>
                </ul>
            </nav>
            <div class="header-actions">
                <a href="pesanan.php" class="cart-icon"><i class="fas fa-shopping-cart"></i></a>
                <div class="user-info">
                    <span class="username"><?php echo htmlspecialchars($username); ?></span>
                    <a href="logout.php" class="btn-logout">Logout</a>
                </div>
            </div>
            <div class="menu-icon">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </header>

    <main>
        <section class="payment-section">
            <div class="payment-container">
                <h2>Total Pembayaran Anda</h2>
                <div class="payment-info">
                    <p>Nomor Pesanan: **<?php echo htmlspecialchars($id_pesanan); ?>**</p>
                    <p class="total-amount">Rp <?php echo number_format($grand_total, 0, ',', '.'); ?></p>
                </div>

                <div class="qris-section">
                    <h3>Bayar dengan QRIS</h3>
                    <img src="assets/QRIS.jpg" alt="QRIS Payment" class="qris-image">
                    <p class="payment-instructions">
                        Silakan scan kode QRIS di atas menggunakan aplikasi mobile banking atau e-wallet Anda.
                    </p>
                    <div class="payment-instructions">
                        <h4>Cara Pembayaran:</h4>
                        <ol>
                            <li>Buka aplikasi pembayaran Anda (misal: GoPay, OVO, Dana, mobile banking).</li>
                            <li>Pilih fitur "Scan QRIS" atau "Pembayaran QR".</li>
                            <li>Arahkan kamera ke kode QR di atas.</li>
                            <li>Pastikan nominal pembayaran adalah **Rp <?php echo number_format($grand_total, 0, ',', '.'); ?>**.</li>
                            <li>Konfirmasi pembayaran.</li>
                            <li>Setelah pembayaran berhasil, Anda akan menerima konfirmasi pesanan.</li>
                        </ol>
                    </div>
                </div>

                <form action="process_payment_confirmation.php" method="POST">
                    <input type="hidden" name="id_pesanan" value="<?php echo htmlspecialchars($id_pesanan); ?>">
                    <input type="hidden" name="total_pembayaran" value="<?php echo htmlspecialchars($grand_total); ?>">
                    <button type="submit" class="btn-primary btn-confirm-payment">Saya Sudah Membayar</button>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <div class="footer-left">
                <div class="logo">
                    <img src="assets/SWEETLOAF.png" alt="SweetLoaf Bakery Logo">
                </div>
                <div class="social-media">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="footer-right">
                <h4>Lokasi :</h4>
                <div class="map-placeholder">
                    <img src="assets/map-placeholder.png" alt="Map Location">
                </div>
            </div>
        </div>
        <div class="copyright">
            <p>ESKALA Copyright 2025. All Rights Reserved.</p>
        </div>
    </footer>
    <script src="order.js"></script>
</body>
</html>